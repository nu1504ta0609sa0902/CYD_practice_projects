#include "images.h"

const ext_img_desc_t images[4] = {
    { "tinyHorse_red", &img_tiny_horse_red },
    { "tinyHorse_green", &img_tiny_horse_green },
    { "tinyHorse_yellow", &img_tiny_horse_yellow },
    { "tinyHorse_blue", &img_tiny_horse_blue },
};
