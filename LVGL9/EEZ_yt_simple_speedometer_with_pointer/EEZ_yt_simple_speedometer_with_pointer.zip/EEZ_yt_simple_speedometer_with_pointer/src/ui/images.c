#include "images.h"

const ext_img_desc_t images[2] = {
    { "imageArcBG", &img_image_arc_bg },
    { "imgNeedle", &img_img_needle },
};
