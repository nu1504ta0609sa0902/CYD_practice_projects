#ifndef EEZ_LVGL_UI_SCREENS_H
#define EEZ_LVGL_UI_SCREENS_H

#include <lvgl.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _objects_t {
    lv_obj_t *main;
    lv_obj_t *btn_change_color;
    lv_obj_t *btn_change_color_label;
    lv_obj_t *btn_change_color_random;
    lv_obj_t *btn_change_color_random_label;
    lv_obj_t *btn_text;
    lv_obj_t *btn_text_label;
    lv_obj_t *label_count;
    lv_obj_t *label_event_fired;
    lv_obj_t *label_text;
    lv_obj_t *panel_switch;
    lv_obj_t *switch_button_change_color;
    lv_obj_t *switch_button_change_color_random;
    lv_obj_t *switch_button_change_text;
    lv_obj_t *switch_label_change_text;
    lv_obj_t *switch_label_show_count;
} objects_t;

extern objects_t objects;

enum ScreensEnum {
    SCREEN_ID_MAIN = 1,
};

void create_screen_main();
void tick_screen_main();

void create_screens();
void tick_screen(int screen_index);


#ifdef __cplusplus
}
#endif

#endif /*EEZ_LVGL_UI_SCREENS_H*/