#include "images.h"

const ext_img_desc_t images[10] = {
    { "Arsenal", &img_arsenal },
    { "Tottenham", &img_tottenham },
    { "AstonVilla", &img_aston_villa },
    { "Brentford", &img_brentford },
    { "Brighton", &img_brighton },
    { "Chelsea", &img_chelsea },
    { "Fulham", &img_fulham },
    { "Liverpool", &img_liverpool },
    { "ManCity", &img_man_city },
    { "Newcastle", &img_newcastle },
};
