#include "images.h"

const ext_img_desc_t images[2] = {
    { "_BG_img", &img__bg_img },
    { "_FG_img", &img__fg_img },
};
