#include "images.h"

const ext_img_desc_t images[1] = {
    { "compass", &img_compass },
};
