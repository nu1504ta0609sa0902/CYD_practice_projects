#ifndef EEZ_LVGL_UI_STRUCTS_H
#define EEZ_LVGL_UI_STRUCTS_H



#if defined(EEZ_FOR_LVGL)

#include <eez/flow/flow.h>
#include <stdint.h>
#include <stdbool.h>

#include "vars.h"

using namespace eez;





#endif

#endif /*EEZ_LVGL_UI_STRUCTS_H*/
