#include "images.h"

const ext_img_desc_t images[1] = {
    { "temperature_bar", &img_temperature_bar },
};
